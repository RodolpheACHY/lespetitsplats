import {
    setIngredientList,
    getIngredientList,
    setApplianceList,
    getApplianceList,
    setUstensilesList,
    getUstensilesList,
} from "./store.js";


// fonction qui affiche notre liste initiale d'ingrédients
export function initDropdownIngredient(recipes) {
  // Créer un ensemble pour stocker tous les ingrédients
  const allIngredients = new Set();
  // Parcourir chaque recette pour récupérer tous les ingrédients
  recipes.forEach((recipe) => {
    recipe.ingredients.forEach((ingredient) => {
      allIngredients.add(ingredient.ingredient.toLowerCase());
    });
  });
  setIngredientList(Array.from(allIngredients).sort());
  displayFilteredIngredients(getIngredientList());
}

// fonction qui affiche notre liste initiale des appareils
export function initDropdownAppliances(recipes) {
  // Créer un ensemble pour stocker tous les appareils
  const allAppliances = new Set();
  // Parcourir chaque recette pour récupérer tous les appareils
  recipes.forEach((recipe) => {
      allAppliances.add(recipe.appliance.toLowerCase());
  });  
  setApplianceList(Array.from(allAppliances).sort());
  //displayFilteredAppliances(Array.from(allAppliances));
  displayFilteredAppliances(getApplianceList());
}

// fonction qui affiche notre liste initiale d'ingrédients
export function initDropdownUstensiles(recipes) {
  // Créer un ensemble pour stocker tous les ingrédients
  const allUstensiles = new Set();
  // Parcourir chaque recette pour récupérer tous les ingrédients
  recipes.forEach((recipe) => {
    recipe.ustensils.forEach((ustensil) => {
      allUstensiles.add(ustensil.toLowerCase());
    });
  });
  setUstensilesList(Array.from(allUstensiles).sort());
  //displayFilteredUstensiles(Array.from(allUstensiles));
  displayFilteredUstensiles(getUstensilesList());
}
