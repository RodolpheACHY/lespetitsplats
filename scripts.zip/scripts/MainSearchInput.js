
export function handleSearch(recipes, query) {
  const trimmedQuery = query.trim().toLowerCase();
  if (trimmedQuery.length >= 3) {
    const filteredRecipes = recipes.filter(
      (recipe) =>
        recipe.name.toLowerCase().includes(trimmedQuery) ||
        recipe.description.toLowerCase().includes(trimmedQuery) ||
        recipe.ingredients.some((ingredient) =>
          ingredient.ingredient.toLowerCase().includes(trimmedQuery)
        )
    );
    displayRecipes(filteredRecipes);
    // Vérifier et afficher le message
    displayNoResultsMessage(query, filteredRecipes, "no-results-message");
  } else {
    displayRecipes(recipes); // Affiche toutes les recettes si la saisie est inférieure à 3 caractères
    displayNoResultsMessage(query, recipes, "no-results-message");
  }
}
