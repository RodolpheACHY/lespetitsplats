import { recipes } from "../../data/recipes.js"; 

export function getRecipes() {
    console.log(recipes);
    return recipes;
}
