
export function clearIngredientsList(ingredientsList) {
    ingredientsList.innerHTML = "";
}

export function clearAppliancesList(appliancesList) {
    appliancesList.innerHTML = "";
}

export function clearUstensilesList(ustensilesList) {
    ustensilesList.innerHTML = "";
}